var n = 10;

function calcular(){
    let resto = 10 / 2;
    return resto;
}

console.log(calcular());